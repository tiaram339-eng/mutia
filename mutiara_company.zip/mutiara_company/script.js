document.addEventListener('DOMContentLoaded', () => {

    // 1. SYSTEM INTERAKTIF TABS (EKOSISTEM)
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Hapus kelas aktif dari semua tombol tab
            tabButtons.forEach(btn => btn.classList.remove('active'));
            // Hapus kelas aktif dari semua isi konten
            tabContents.forEach(content => content.classList.remove('active'));

            // Aktifkan tab yang diklik
            button.classList.add('active');
            const targetedTabId = button.getAttribute('data-tab');
            document.getElementById(targetedTabId).classList.add('active');
        });
    });


    // 2. LIVE NUMBER COUNTER ENGINE (ANIMASI ANGKA STATISTIK)
    const statNumbers = document.querySelectorAll('.stat-number');
    
    const startCounter = (element) => {
        const target = parseInt(element.getAttribute('data-target'));
        let count = 0;
        const speed = target / 50; // Kecepatan distribusi bertahap durasi konstan

        const updateNumber = () => {
            count += speed;
            if (count < target) {
                element.innerText = Math.floor(count);
                setTimeout(updateNumber, 20);
            } else {
                element.innerText = target;
            }
        };
        updateNumber();
    };


    // 3. SCROLL REVEAL INTEGRATION & SCROLL-TRIGGERED STATS
    const revealElements = document.querySelectorAll('.reveal');
    
    const globalObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                // Trigger efek visual pemudar
                entry.target.classList.add('active');

                // Khusus jika elemen yang beririsan adalah kartu statistik, jalankan live counter
                if (entry.target.classList.contains('stat-card')) {
                    const numberEl = entry.target.querySelector('.stat-number');
                    if(numberEl && numberEl.innerText === '0') {
                        startCounter(numberEl);
                    }
                }
                
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: "0px 0px -40px 0px"
    });

    // Daftarkan semua elemen deteksi ke observer
    revealElements.forEach(el => globalObserver.observe(el));
    // Tambahkan kelas deteksi pada kartu stat untuk memicu counter angka secara individual
    document.querySelectorAll('.stat-card').forEach(card => {
        card.classList.add('reveal');
        globalObserver.observe(card);
    });


    // 4. STICKY GLASSMORPHISM SCROLL INTERACTION FOR NAVBAR
    const navbar = document.querySelector('.navbar');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });


    // 5. HAMBURGER RESPONSIVE TOGGLE MENU
    const menuToggle = document.querySelector('.menu-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if(menuToggle && navMenu) {
        menuToggle.addEventListener('click', () => {
            navMenu.classList.toggle('open');
            menuToggle.classList.toggle('open');
        });
    }
});